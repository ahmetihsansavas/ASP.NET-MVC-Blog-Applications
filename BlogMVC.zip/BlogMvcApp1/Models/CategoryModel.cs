﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BlogMvcApp1.Models
{
    public class CategoryModel
    {
        //blog sayısını tutmak için categorymodel oluşturduk..
        public int Id { get; set; }
        public string KategoriAdi { get; set; }
        public int BlogSayisi { get; set; }
    }
}