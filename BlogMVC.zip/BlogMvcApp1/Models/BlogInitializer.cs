﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace BlogMvcApp1.Models
{
    public class BlogInitializer:DropCreateDatabaseIfModelChanges<BlogContext>
    {
        protected override void Seed(BlogContext context)
        {
            List<Category> kategoriler = new List<Category>()

            {
                new Category(){KategoriAdi="C#"},
                new Category(){KategoriAdi="ASP.Net MVc"},
                new Category(){KategoriAdi="ASP.Net Web Forms"},
                new Category(){KategoriAdi="C++"},
                new Category(){KategoriAdi="C"}
            };

            foreach (var kategori in kategoriler)
            {
                context.Kategoriler.Add(kategori);
            }
            context.SaveChanges();

            List<Blog> bloglar = new List<Blog>()
            {

                new Blog(){Baslik="C# Delagates HakkındaC# Delagates HakkındaC# Delagates HakkındaC# Delagates HakkındaC# Delagates HakkındaC# Delagates HakkındaC# Delagates HakkındaC# Delagates HakkındaC# Delagates Hakkında",Aciklama="C# Delagates HakkındaC# Delagates HakkındaC# Delagates Hakkında" ,
                    EklenmeTarihi =DateTime.Now.AddDays(-10),Anasayfa=true,Onay=true,Icerik="C# Delagates HakkındaC# Delagates HakkındaC# Delagates HakkındaC# Delagates HakkındaC# Delagates Hakkında",
                    Resim ="1.jpg",CategoryId=1},
                new Blog(){Baslik="C# Delagates Hakkında",Aciklama="C# Delagates HakkındaC# Delagates HakkındaC# Delagates Hakkında" ,
                    EklenmeTarihi =DateTime.Now.AddDays(-10),Anasayfa=true,Onay=true,Icerik="C# Delagates HakkındaC# Delagates HakkındaC# Delagates HakkındaC# Delagates HakkındaC# Delagates Hakkında",
                    Resim ="2.jpg",CategoryId=2},
                new Blog(){Baslik="C# Delagates Hakkında",Aciklama="C# Delagates HakkındaC# Delagates HakkındaC# Delagates Hakkında" ,
                    EklenmeTarihi =DateTime.Now.AddDays(-10),Anasayfa=false,Onay=true,Icerik="C# Delagates HakkındaC# Delagates HakkındaC# Delagates HakkındaC# Delagates HakkındaC# Delagates Hakkında",
                    Resim ="2.jpg",CategoryId=2},
                new Blog(){Baslik="C# Generic List Delagates Hakkında",Aciklama="C# Delagates HakkındaC# Delagates HakkındaC# Delagates Hakkında" ,
                    EklenmeTarihi =DateTime.Now.AddDays(-10),Anasayfa=true,Onay=true,Icerik="C# Delagates HakkındaC# Delagates HakkındaC# Delagates HakkındaC# Delagates HakkındaC# Delagates Hakkında",
                    Resim ="3.jpg",CategoryId=3},
                new Blog(){Baslik="C# Delagates Hakkında",Aciklama="C# Delagates HakkındaC# Delagates HakkındaC# Delagates Hakkında" ,
                    EklenmeTarihi =DateTime.Now.AddDays(-40),Anasayfa=true,Onay=false,Icerik="C# Delagates HakkındaC# Delagates HakkındaC# Delagates HakkındaC# Delagates HakkındaC# Delagates Hakkında",
                    Resim ="3.jpg",CategoryId=3},
                new Blog(){Baslik="C# Delagates Hakkında",Aciklama="C# Delagates HakkındaC# Delagates HakkındaC# Delagates Hakkında" ,
                    EklenmeTarihi =DateTime.Now.AddDays(-30),Anasayfa=true,Onay=true,Icerik="C# Delagates HakkındaC# Delagates HakkındaC# Delagates HakkındaC# Delagates HakkındaC# Delagates Hakkında",
                    Resim ="3.jpg",CategoryId=3},
                new Blog(){Baslik="C# Delagates Hakkında",Aciklama="C# Delagates HakkındaC# Delagates HakkındaC# Delagates Hakkında" ,
                    EklenmeTarihi =DateTime.Now.AddDays(-10),Anasayfa=false,Onay=true,Icerik="C# Delagates HakkındaC# Delagates HakkındaC# Delagates HakkındaC# Delagates HakkındaC# Delagates Hakkında",
                    Resim ="4.jpg",CategoryId=4},
                new Blog(){Baslik="C# Delagates Hakkında",Aciklama="C# Delagates HakkındaC# Delagates HakkındaC# Delagates Hakkında" ,
                    EklenmeTarihi =DateTime.Now.AddDays(-20),Anasayfa=true,Onay=true,Icerik="C# Delagates HakkındaC# Delagates HakkındaC# Delagates HakkındaC# Delagates HakkındaC# Delagates Hakkında",
                    Resim ="4.jpg",CategoryId=4},
                new Blog(){Baslik="C# Delagates Hakkında",Aciklama="C# Delagates HakkındaC# Delagates HakkındaC# Delagates Hakkında" ,
                    EklenmeTarihi =DateTime.Now.AddDays(-30),Anasayfa=true,Onay=false,Icerik="C# Delagates HakkındaC# Delagates HakkındaC# Delagates HakkındaC# Delagates HakkındaC# Delagates Hakkında",
                    Resim ="4.jpg",CategoryId=4},
                new Blog(){Baslik="C# Can Sıkıntısı Hakkında",Aciklama="C# Delagates HakkındaC# Delagates HakkındaC# Delagates Hakkında" ,
                    EklenmeTarihi =DateTime.Now.AddDays(-30),Anasayfa=true,Onay=true,Icerik="C# Delagates HakkındaC# Delagates HakkındaC# Delagates HakkındaC# Delagates HakkındaC# Delagates Hakkında",
                    Resim ="4.jpg",CategoryId=4},
                new Blog(){Baslik="C# Can sıkıntısı Hakkında",Aciklama="C# Delagates HakkındaC# Delagates HakkındaC# Delagates Hakkında" ,
                    EklenmeTarihi =DateTime.Now.AddDays(-10),Anasayfa=true,Onay=true,Icerik="C# Delagates HakkındaC# Delagates HakkındaC# Delagates HakkındaC# Delagates HakkındaC# Delagates Hakkında",
                    Resim ="5.jpg",CategoryId=5},


            };
            foreach (var blog in bloglar)
            {
                context.Bloglar.Add(blog);

            }

            context.SaveChanges();


            base.Seed(context);
        }
    }
}